#!/usr/bin/env python3

import cgi
import os
import cgitb

cgitb.enable()

# Установка каталога CGI
os.chdir(os.path.dirname(__file__))
cgi_directory = os.path.join(os.getcwd(), "CGI")
if not os.path.exists(cgi_directory):
    os.makedirs(cgi_directory)

form = cgi.FieldStorage()
name = form.getvalue('name')
faculty = form.getvalue('faculty')
email = form.getvalue('email')
condition = form.getvalue('condition')


length = 14
numbers = range(length)
byte_sequence = bytes(numbers)

number = 8

offset = 10  
from_where = 0

if name and faculty and email:
    
    with open('CGI/names.txt', 'a', encoding='utf-8') as names_file:
        names_file.writelines(f"{name}\n")

    with open('CGI/values.txt', 'a', encoding='utf-8') as values_file:
        values_file.writelines(f"{faculty},{email}\n")
        
    file_name_path = 'CGI/names.txt'
    file_name_size = os.path.getsize(file_name_path)
    file_values_path = 'CGI/values.txt'
    file_values_size = os.path.getsize(file_values_path)
    
    with open(file_values_path, 'r', encoding='utf-8') as values_file:
        lines = values_file.readlines()

    with open("binary_data.dat", "wb") as binary_file:
        binary_file.write(byte_sequence)
    
    with open("binary_data.dat", "rb") as binary_file:
        binary_file.seek(number)
        number_value = binary_file.read(1)
    
    with open("binary_data.dat", "rb") as binary_file:
        binary_file.seek(offset, from_where)
        data = binary_file.read(3)
    
    print("Content-Type: text/html; charset=utf-8")
    print()
    print("<html><body>")
    print("<h1>Данные успешно отправлены!</h1>")
    print(f"<br>Размер файла names: {file_name_size} байт")
    print(f"<br>Размер файла values: {file_values_size} байт")
    
    for line in lines:
        print(f"<H4>{line}</H4>")
    
    print(f"Последовательность чисел длиной {length} записана в файл 'binary_data.dat'.")
    print("<br>Прочитанное значение при номере 8: ", list(number_value))
    print("<br>Прочитанные значения в колоноке: ", list(data))
    
    try :
        assert (data[2] == condition)
        print ( '<br>Да, колонока оканчивается на ', condition)
        
    except AssertionError :
        print ( '<br>Нет, колонока не оканчивается на', condition)

    
    print("</body></html>")
else:
    print("Content-Type: text/html; charset=utf-8")
    print()
    print("<html><body>")
    print("<h1>Ошибка: Не все поля заполнены!</h1>")
    print("</body></html>")
